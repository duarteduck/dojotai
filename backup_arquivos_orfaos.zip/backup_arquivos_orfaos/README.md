# Backup de Arquivos Órfãos - Sistema Dojotai

## Data do Backup: 30/09/2025

Este diretório contém arquivos que foram identificados como não utilizados durante a análise completa do sistema.

## Arquivos Movidos

### Componentes (src/05-components/)
- `calendarModal.html` - Modal de calendário não referenciado
- `memberCard.html` - Card de membro não utilizado
- `pageActions.html` - Ações de página não utilizadas
- `userMenu.html` - Menu de usuário não referenciado

### Views (src/04-views/)
- `practices.html` - View de práticas não utilizada
- `view_dash.html` - View de dashboard alternativa
- `view_members_list.html` - Lista de membros não utilizada

### Shared (src/03-shared/)
- `app_state.html` - Estado de aplicação não utilizado
- `styles_base.html` - Estilos base não referenciados

## Motivo da Movimentação

Estes arquivos não são referenciados no arquivo principal `app_migrated.html` que contém toda a aplicação frontend de forma monolítica.

## Recuperação

Para recuperar qualquer arquivo:
1. Copie o arquivo de volta para sua localização original em `src/`
2. Adicione referência no código principal se necessário
3. Teste a funcionalidade

## Próximos Passos

- [ ] Confirmar que sistema funciona normalmente
- [ ] Aguardar 30 dias antes de exclusão definitiva
- [ ] Documentar funcionalidades que podem precisar destes arquivos